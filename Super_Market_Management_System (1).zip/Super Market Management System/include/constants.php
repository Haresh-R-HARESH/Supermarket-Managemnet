<?php
define("DB_SERVER","127.0.0.1");
define("DB_USER","root");
define("DB_PASSWORD","");
define("DB_NAME","supermarket");
//define("FILE_ADD","C:\\xampp\\htdocs\\webblog\\backend\\articles\\");
?>