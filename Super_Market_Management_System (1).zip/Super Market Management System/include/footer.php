
<div class="footer">
	Developed by<br> College Projects for CS <br />
</div>
<?php
//close connection
if(isset($connect))
mysql_close();
?>

<!--body closes-->
</div>
</body>
</html>
